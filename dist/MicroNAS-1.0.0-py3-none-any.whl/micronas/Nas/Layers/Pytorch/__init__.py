from micronas.Nas.Layers.Pytorch.ChooseNParallel import ChooseNParallel, ChooseNParallel_v2
from micronas.Nas.Layers.Pytorch.Sequential import Sequential
from micronas.Nas.Layers.Pytorch.MakeChoice import MakeChoice, Parallel_Choice_Add
from micronas.Nas.Layers.Pytorch.Common import * 